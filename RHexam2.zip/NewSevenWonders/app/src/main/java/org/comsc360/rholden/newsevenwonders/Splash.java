package org.comsc360.rholden.newsevenwonders;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

public class Splash extends AppCompatActivity {
    MediaPlayer song;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
   super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_splash);
        song= new MediaPlayer();
        song=MediaPlayer.create(this,R.raw.song);
        song.start();
    TimerTask task= new TimerTask(){

        public void run(){

            finish();
            song.stop();
            startActivity(new Intent(Splash.this,MainActivity.class));

        }
    };
    //Create yout itmer object
    Timer opening = new Timer();
        opening.schedule(task,5000);//milliseconds
}
}
