package org.comsc360.rholden.newsevenwonders;

import android.content.Context;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Integer[] wonders={R.drawable.itza,R.drawable.machu,R.drawable.man,R.drawable.peta,R.drawable.rome,R.drawable.spink, R.drawable.taji, R.drawable.wall};
    ImageView pic;
    ImageView large;
    MediaPlayer tune;
        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            GridView grid=findViewById(R.id.gridView);
             pic = findViewById(R.id.imgLarge);
            grid.setAdapter(new ImageAdaptor(this));
            tune= new MediaPlayer();
            tune=MediaPlayer.create(this,R.raw.song);

            grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    Toast.makeText(getBaseContext(),"Selceted Wonder: "+ (i+1), Toast.LENGTH_SHORT).show();
                    pic.setImageResource(wonders[i]);
                    if(tune.isPlaying()) {
                        tune.pause();
                        tune.seekTo(0);
                    }
                    else {
                        tune.start();
                    }

                }
            });
    }

    //add the ImaeAdptor
    public class ImageAdaptor extends BaseAdapter {
        private Context context;

        public ImageAdaptor(Context c) {
            context =c;
        }
        @Override
        public int getCount() {
            return wonders.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            large=new ImageView(context);
            large.setImageResource(wonders[i]);
            large.setScaleType(ImageView.ScaleType.FIT_XY);
            large.setLayoutParams(new GridView.LayoutParams(330,300));


            return large;
        }
    }
}
